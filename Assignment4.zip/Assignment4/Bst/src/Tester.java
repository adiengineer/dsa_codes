import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
     Scanner sc=new Scanner(System.in);		

     //create tree
     Bst b=new Bst();
     
     while (true)
     {
    	 int input=Integer.parseInt(sc.nextLine());
    	 
    	 if (input==-5)
    		 break;
    	 
    	 b.insert(b.root,input,null);
       	
     }
     
//     b.zigzag(); call for zig zag
     
    /* while (true)
     {
    	 int input=Integer.parseInt(sc.nextLine());
    	 
    	 if (input==-5)
    		 break;
    	 
    	 //int max=b.maximum(b.root);
    	// int suc=b.predecessor(input);
    	 
    	 Node curr=b.search(input,0,b.root);
    	   
    	 
    	 //for subtree size
    	 //if (curr!=null && curr.left!=null) //then we can find size left sub
    	 //      System.out.println(b.sizesub(curr.right));
    	 
    	 
    	 //for depth
    	// System.out.println(b.depth(curr));
    	 
    		// System.out.println(suc);
    	 
    	 //for height check
    	// System.out.println(b.height(curr, 0));
     }*/
    
     //call for itepreorder.
     //b.itepreorder(b.root);
     //b.itepostorder(b.root);
     
    // b.iteintorder(b.root);
     
    //delete function has also been written.
     b.findrankall(b.root,1,0);
     //b.inorder(b.root);
      
   
     //code for checking k adv Q1
     /*
     while (true)
     {
    	int left=Integer.parseInt(sc.nextLine());
    	int right=Integer.parseInt(sc.nextLine());
    	if (left==-5)
    		break;
    	
    	
    	System.out.println(b.precisesub(left,right));
     }*/
     
     //code for checking AdvQ6
     b.subpair(Integer.parseInt(sc.nextLine()));
     
     System.out.println(); 
      
     sc.close();
	}

//this func assumes that curr is not null and has a left sub, upper check required.
	
}
