
public class Treap 
{
   TreapNode root;
   
   //recursive treap insert which includes tree rotations
    public TreapNode insert(int x,int priority, TreapNode t,TreapNode parent)
    {
    	//base case
    	if (root==null)
    	  {root=new TreapNode(x,priority,null);
    	   return null;
    	  }
    	if (t==null)
    		return (new TreapNode(x,priority,parent));
    	
    	//bin tree rule
    	if (x<=t.key)
    	{
    		t.left=insert(x,priority,t.left,t);
    		
    		//now I have to check if the child returned respects the priority
    		
    		//this implies max heap prop not satisfied
    		if (t.left.priority>t.priority)
    		{
    			//do something
    			TreapNode l=t.left;
    			// will have to rotate.
    			
    			//code for changing the parent pointers.
    			l.parent=t.parent;
    			t.parent=l; // change parent of old parent.
    			
    			if (l.right!=null)
    			l.right.parent=t; //change parent of right node of the old child.
    			
    			
    			t.left=l.right;
    			
    			l.right=t;
    			
    			
    			
    			//to give r a newparent return r, because this call was done by the parent and it
    			//is asking for its child.
    			
    			return l;
    		}
    		
    		//if no problem just return T
    		return t;
    	}
    	
    	
    	
    		t.right=insert(x,priority,t.right,t);
    		
    		//now I have to check if the child returned respects the priority
    		
    		//this implies max heap prop not satisfied
    		if (t.right.priority>t.priority)
    		{
    			//do something
    			TreapNode r=t.right;
    			// will have to rotate.
 
    			//code for changing the parent pointers.
    			
    			r.parent=t.parent;
    			
    			if (t!=null)
    			t.parent=r; // change parent of old parent.
    			
    			if (r.right!=null)
    			r.right.parent=t; //change parent of right node of the old child.

    			
    			
    			
    			t.right=r.left;
    			r.left=t;
    			
    			//to give r a newparent return r, because this call was done by the parent and it
    			//is asking for its child.
    			
    			return r;
    		}
    		
    		//if no problem just return T
    		return t;
    	
    }
    
    public void printlevel()
    {
   	 int newlinecount=0;
   	 Queue q =new Queue();
   	 
   	  TreapNode curr=root;
   	  
   	  if (curr==null)
   	  {
   		  System.out.println("Nothing to print");
   		  return;
   	  }
   	  
   	System.out.println(curr.key+"/"+curr.priority+"p");
   	
   	    //assume 5.
   	//now enqueue all children.
   
   	
   		if (curr.left!=null)
   		q.insert(curr.left);
   	    if (curr.right!=null)
   	    	q.insert(curr.right);	
   	
   	newlinecount=q.size;
   	
   	while(q.size!=0)
   	{
   	    curr=q.delete();
   		
   	  if (curr.left!=null)
     		q.insert(curr.left);
     	    if (curr.right!=null)
     	    	q.insert(curr.right);
   		
   		
   		System.out.print(curr.key+"/"+curr.priority +"p"+curr.parent.key+" ");
   		newlinecount--;
   		
   		if (newlinecount==0)
   			{System.out.println();
   		newlinecount=q.size;    		
   			}
   	}
    }
}
