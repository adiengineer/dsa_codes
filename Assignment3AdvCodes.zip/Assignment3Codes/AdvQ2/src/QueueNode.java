





public class QueueNode
{  
	 TreapNode data=null;
      QueueNode next=null;
    
	public TreapNode getData() {
		return data;
	}
	public void setData(TreapNode data) {
		this.data = data;
	}
	public QueueNode getNext() {
		return next;
	}
	public void setNext(QueueNode next) {
		this.next = next;
	}

     
     
}


