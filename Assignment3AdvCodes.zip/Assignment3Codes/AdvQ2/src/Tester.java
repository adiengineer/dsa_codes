import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        
		Treap tr=new Treap();
		
		System.out.println("Insert key value priority pair one by one on seperate lines!");
		System.out.println("To display enter -5. Level order tree representation will be displayed.");
		System.out.println("eg: 2");
		System.out.println("5");
		System.out.println("4");
		System.out.println("7");
		System.out.println("the treap is displayed in level order with key/priority/parent form ");
		//TreapNode curr=tr.root;
		while (true)
		{
		   int input=Integer.parseInt(sc.nextLine());
		   
		   if (input==-5)
			   break;
		   
		   int priority=Integer.parseInt(sc.nextLine());
		   
		 tr.insert(input, priority,tr.root,null); //  change made.
		   //tr.printlevel();
		}
		
		tr.printlevel();
		
		sc.close();
	}

}
