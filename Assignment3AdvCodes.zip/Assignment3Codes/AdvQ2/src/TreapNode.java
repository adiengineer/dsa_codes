
public class TreapNode 
{
    int key;
    int priority;
    
    TreapNode left;
    TreapNode right;
    TreapNode parent;
    
    TreapNode(int key,int priority,TreapNode parent)
    {
    	this.key=key;
    	this.priority=priority;
    	this.parent=parent; // must provide the parent.
    	left=null;
    	right=null;
    }
}
