
public class pElement 
{
     int data;
     int priority;
}
