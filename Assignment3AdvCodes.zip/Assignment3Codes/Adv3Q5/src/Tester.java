import java.util.Scanner;

public class Tester 
{

	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
      
	System.out.println("Enter the key and priority on seperate lines with key first");
	System.out.println("At each entry queue is displayed");
	System.out.println("To stop enter -5 as the key");
	
	int data,priority;
	    //test the priority queue.
	     PriorityQueue pq=new PriorityQueue();
	     
	      while (true)
	      {
	    	  data=Integer.parseInt(sc.nextLine());
	    	  if (data==-5)
	    		  break;
	    	  
	    	  priority=Integer.parseInt(sc.nextLine());
	    	  
	    	
	    	  
	    	  pq.priorityInsert(data, priority);
	    	  pq.showQueue();
	      }
	      
	      sc.close();
	}

}
