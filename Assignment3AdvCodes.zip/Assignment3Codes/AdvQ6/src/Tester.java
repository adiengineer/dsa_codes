import java.util.Scanner;
public class Tester 
{
	//a pointer to a queue.
    public static Queue oldheap=new Queue(); 
	public static Queue currheap=new Queue(); //this will find largerst max heap for curr node.
    public static Queue largest=new Queue();
    public static Queue largestmin=new Queue();
    public static Queue temp;
	public static void main(String[] args) 
	{
		// initiate scanner
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter array size N on first line");
		System.out.println("On next N lines enter the array elements");
		System.out.println("The function tells you what is the largest sub heap");
		 int limit;
		 
		 limit=Integer.parseInt(sc.nextLine());
		 int[] heap =new int[limit];
		
		 
		 
		 
		 //we need to take in the heap.
		     for(int i=0;i<heap.length;i++)
			    heap[i]=Integer.parseInt(sc.nextLine());
		 
		// we need a heap to test on
		//after call to largesr submaxheap, we will get largst possible max heap for that i.
		
	   	//now we find the global largest max heap
		
	     //compute for root.
		 //this call will give max heap containing root. curr will be set.
		largestSubMaxHeap(heap,0);
		
		//initialize for root, remember that currheap will have to be flushed.
		temp=largest; //temp pointer.
		largest=currheap;
		currheap=temp;
		 
		for(int i=1;i<heap.length;i++)
		{
			int trash;
			//compute for i;
			largestSubMaxHeap(heap,i); //curr will be set
			
			if (currheap.size>largest.size)
			{
				// swap them
				temp=largest; //temp pointer.
				largest=currheap;
				currheap=temp;
			}
			
			//flush currheap for reuse.
			 while(currheap.size>0)
				 trash=currheap.delete();
			 
		}
		
		largestSubMinHeap(heap,0);
		temp=largestmin; //temp pointer.
		largestmin=currheap;
		currheap=temp;
		
		for(int i=1;i<heap.length;i++)
		{
			int trash;
			//compute for i;
			largestSubMinHeap(heap,i); //curr will be set
			
			if (currheap.size>largestmin.size)
			{
				// swap them
				temp=largestmin; //temp pointer.
				largestmin=currheap;
				currheap=temp;
			}
			
			//flush currheap for reuse.
			 while(currheap.size>0)
				 trash=currheap.delete();
			 
		}
		
		if (largest.size>largestmin.size)
		{//at the end of this for loop we should get max possible heap.
        largest.show();
        
		}
		
		
		if (largest.size<largestmin.size)
        largestmin.show();
		 
		if (largest.size==largestmin.size)
		{
			largest.show();
			largestmin.show();
		}
        sc.close();
	}

	
	//function to find largest sub maxheap for a given i.
	//elements guarenteed to be distinct
	
	public static void largestSubMaxHeap(int[] heap,int i)
	{
		Queue childindices=new Queue(); //used to store child indices.
		int curr=i; 
		
		//at minimum a heap has to contain one node.
		//initial setup for the loop.
		
		 currheap.insert(heap[i]);
		 
		   if (2*i+1>=heap.length) //trivial subheap for a leaf node.
			   return;
		   
		   childindices.insert(2*i+1);
		   
		   if (heap[2*i+1]>heap[i])
			   return;
		   
		   //otherwise
			   currheap.insert(heap[2*i+1]);
		   
		   //now if root has no right child then heap is finished.
		   if (2*i+2>=heap.length)
			   return;
		   
		   childindices.insert(2*i+2);
		   
		   //otherwise record root's right child if it satis hp
		   if (heap[2*i+2]>heap[i])
			   return;
		   
		   currheap.insert(heap[2*i+2]);
		   
		   //now if it has both children then loop.
		   while (true)
		   {
			   curr=childindices.delete();
			   
			   if (2*curr+1>=heap.length) //trivial subheap for a leaf node.
				   return;
			   
			   childindices.insert(2*curr+1);
			   
			   if (heap[2*curr+1]>heap[curr])
				   return;
			   
			   //otherwise
				   currheap.insert(heap[2*curr+1]);
			   
			   //now if root has no right child then heap is finished.
			   if (2*curr+2>=heap.length)
				   return;
			   
			   childindices.insert(2*curr+2);
			   
			   //otherwise record root's right child if it satis hp
			   if (heap[2*curr+2]>heap[curr])
				   return;
			   
			   currheap.insert(heap[2*curr+2]);
			   
			   //if any problem it will return.
			   
			     if (childindices.size<=0)
			    	 break;
		   }
	}
	
	public static void largestSubMinHeap(int[] heap,int i)
	{
		Queue childindices=new Queue(); //used to store child indices.
		int curr=i; 
		
		//at minimum a heap has to contain one node.
		//initial setup for the loop.
		
		 currheap.insert(heap[i]);
		 
		   if (2*i+1>=heap.length) //trivial subheap for a leaf node.
			   return;
		   
		   childindices.insert(2*i+1);
		   
		   if (heap[2*i+1]<heap[i])
			   return;
		   
		   //otherwise
			   currheap.insert(heap[2*i+1]);
		   
		   //now if root has no right child then heap is finished.
		   if (2*i+2>=heap.length)
			   return;
		   
		   childindices.insert(2*i+2);
		   
		   //otherwise record root's right child if it satis hp
		   if (heap[2*i+2]<heap[i])
			   return;
		   
		   currheap.insert(heap[2*i+2]);
		   
		   //now if it has both children then loop.
		   while (true)
		   {
			   curr=childindices.delete();
			   
			   if (2*curr+1>=heap.length) //trivial subheap for a leaf node.
				   return;
			   
			   childindices.insert(2*curr+1);
			   
			   if (heap[2*curr+1]<heap[curr])
				   return;
			   
			   //otherwise
				   currheap.insert(heap[2*curr+1]);
			   
			   //now if root has no right child then heap is finished.
			   if (2*curr+2>=heap.length)
				   return;
			   
			   childindices.insert(2*curr+2);
			   
			   //otherwise record root's right child if it satis hp
			   if (heap[2*curr+2]<heap[curr])
				   return;
			   
			   currheap.insert(heap[2*curr+2]);
			   
			   //if any problem it will return.
			   
			     if (childindices.size<=0)
			    	 break;
		   }
	}
}
