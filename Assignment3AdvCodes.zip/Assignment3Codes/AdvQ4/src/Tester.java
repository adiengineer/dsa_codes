import java.util.Scanner;
public class Tester 
{
	 //static int non=0; // object attribute any func can use it .
	 
	 
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int limit;
		
		System.out.println("Enter a number n to see how many heaps of size n are possible by permuting the distinct elements in it");
		
		limit=Integer.parseInt(sc.nextLine());
		
		//heap created.
		int[] heap= new int[limit];
		
		System.out.println(numberofheapsofn(heap,heap.length,0));      
       sc.close();
	}

	//calculates n!
	public static int factorial(int n)
	{
		int fact=1;
		
		for(int i=n;i>=2;i--)
			fact=fact*i;
		
		return fact;
	}
	
	public static int combi(int n,int r)
	{
		
		return (factorial(n)/( factorial(n-r)*factorial(r) ) );
	}
	
	//the start shoud be left child of node I which is to be found
	public static int numberofnodesinleft(int[] heap, int i,int non)
	{
		
		//I itself is null
	    if (i>=heap.length)
	    	return non;
	    
	    non++; //if present it counts itself
	    
	   // if (2*i+1>=heap.length)
	    //	return non;  //change made
	    
	   non=numberofnodesinleft(heap,(2*i+1),non);  //change made.
	    
	   non=numberofnodesinleft(heap,(2*i+2),non); //change made
	   
	   return non;
	}
	
	
	public static int numberofheapsofn(int[] heap,int n,int i)
	{
		//I need to find non for every n, so I need to check it.
		int non=0;int combi;
		
	   if (n==0 ||n==1)
		   return 1;
	   
	   non=numberofnodesinleft(heap,2*i+1,non);   //change made
	   
	   combi=combi(n-1,non);
	   
	   return (combi*numberofheapsofn(heap,non,2*i+1)*numberofheapsofn(heap,(n-non-1),2*i+2));     
	}
}
