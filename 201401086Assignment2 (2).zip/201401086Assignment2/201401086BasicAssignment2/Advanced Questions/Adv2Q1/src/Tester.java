import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		//take in the array size and the circular array, which if will take in a
		//normal array. Note that we have not been asked to create a circular array just search.
		
		int size;
		
		size=Integer.parseInt(sc.nextLine().trim());
        int[] arr=new int[size];
		
		//take in the curcular array.
		for(int i=0;i<size;i++)
		{
			arr[i]=Integer.parseInt(sc.nextLine());
		}
		
		System.out.println(findMax(arr));
		
		sc.close();
	}

	
 public static int findMax(int[] arr)
 {
	int i=0,j=arr.length-1,mid; 
	
	//to find the max we need to find the cut the cutpoint. 
	   while (i<j)
	   {
		   mid=(i+j)/2;
		   
		   if (arr[mid]>=arr[0])
			  i=mid+1;
		   else
			   j=mid-1;
	   }
	   
	   //the  max element will be at i.
	   
	   if (i-1>=0)
	   {if (arr[i]>arr[i-1])
		  return arr[i];
	   else
		   return arr[i-1];
	   }
	   else
		   {
		   if (arr[i]>arr[i+1])
		   return arr[i];
		   else
			   return arr[i+1];
		   }
	   
	  
 }
}
