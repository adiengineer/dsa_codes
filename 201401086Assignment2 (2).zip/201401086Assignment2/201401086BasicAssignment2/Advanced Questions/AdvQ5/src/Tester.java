import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
      //  scan array,size
		  int size;
		  size=Integer.parseInt(sc.nextLine());
		  
		  int[] arr=new int[size];
		  
		  //take in the arr.
		  for(int i=0;i<arr.length;i++)
			  arr[i]=Integer.parseInt(sc.nextLine());
		  
		  System.out.println(findsecondmax(arr));
        
		  sc.close();
	}

	public static int findsecondmax(int[]  arr)
	{
	    // assuming even split.
		 int max=-10,secmax=-10,curr=0,pos=0,currsize,greater;
		 int[] currarr=new int[(arr.length/2+1)];
		 
		 if (arr.length%2==0)
		 {for(int i=0;i<arr.length-1;i=i+2)
		 {
			if (arr[i]>arr[i+1])
			{
				currarr[curr]=arr[i];
				curr++;
				
				if (arr[i]>max)
				{
					max=arr[i];
					pos=i;
				}
			}
			else if (arr[i]<arr[i+1])
			{
				currarr[curr]=arr[i+1];
				curr++;
				
				if (arr[i+1]>max)
				{
					max=arr[i+1];
					pos=i+1;
				}
			}
		 }
		 
		 if (pos%2==0)
		 {
			 if (arr[pos+1]>secmax)
				 secmax=arr[pos+1];
		 }
		 
		 else
			 {if (arr[pos-1]>secmax)
				 secmax=arr[pos-1];
			 }
		 //this should give us the max and the remaining n/2 elements.
		 currsize=arr.length/2;
		 
		 while (currsize>0)
		 {
			 curr=0;
			 
			 for(int i=0;i<currsize-1;i=i+2)
			 {
				  if (currarr[i]>currarr[i+1])
				  {
					  if (currarr[i]==max)
					  {
						  if (currarr[i+1]>secmax)
							  secmax=currarr[i+1];
							  
					  }
					  
					  currarr[curr]=currarr[i];
					  curr++;
				  }
				  else
					  {
					  if (currarr[i+1]==max)
					  {
						  if (currarr[i]>secmax)
							  secmax=currarr[i];
							  
					  }
					  
					  currarr[curr]=currarr[i+1];
					  curr++;
					 }
				  
				  
			 }
			 currsize=currsize/2;
		 }
		 }
		 else
		 {
			 for(int i=0;i<arr.length-1;i=i+2)
			 {
				if (arr[i]>arr[i+1])
				{
					currarr[curr]=arr[i];
					curr++;
					
					if (arr[i]>max)
					{
						max=arr[i];
						pos=i;
					}
				}
				else if (arr[i]<arr[i+1])
				{
					currarr[curr]=arr[i+1];
					curr++;
					
					if (arr[i+1]>max)
					{
						max=arr[i+1];
						pos=i+1;
					}
				}
			 }
			 
			 if (arr[arr.length-1]>max)
			 {
				 max=arr[arr.length-1];
				 pos=arr.length-1;
				 
			 }
			 if (pos%2!=0)
			 {
				 if (arr[pos+1]>secmax)
					 secmax=arr[pos+1];
			 }
			 
			 else
				 {if (arr[pos-1]>secmax)
					 secmax=arr[pos-1];
				 }
			 currarr[curr]=arr[arr.length-1]; //include the last element.
			 //this should give us the max and the remaining n/2 elements.
			 currsize=arr.length/2;
			 
			 while (currsize>0)
			 {
				 curr=0;
				 
				 for(int i=0;i<currsize-1;i=i+2)
				 {
					  if (currarr[i]>currarr[i+1])
					  {
						  if (currarr[i]==max)
						  {
							  if (currarr[i+1]>secmax)
								  secmax=currarr[i+1];
								  
						  }
						  
						  currarr[curr]=currarr[i];
						  curr++;
					  }
					  else
						  {
						  if (currarr[i+1]==max)
						  {
							  if (currarr[i]>secmax)
								  secmax=currarr[i];
								  
						  }
						  
						  currarr[curr]=currarr[i+1];
						  curr++;
						 }
					  
					  
				 }
				 if (currarr[curr]>secmax && currarr[curr]<max)
					 secmax=currarr[curr];
				 currsize=currsize/2;
				 currarr[currsize]=currarr[curr];
			 } 
		 }
		 return secmax;
	}
}
