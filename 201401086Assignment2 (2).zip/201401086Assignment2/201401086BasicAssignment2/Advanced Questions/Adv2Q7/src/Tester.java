import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
	   int n;
	   
        n=Integer.parseInt(sc.nextLine());
        int[][] arr=new int[n][n];
        
        //here we will need to scan the array.
        for(int i=0;i<n;i++)
        {
        	for(int j=0;j<n;j++)
        	 arr[i][j]=Integer.parseInt(sc.nextLine());
        }
        
        showArray(arr);
        
        while(true)
        {int key=Integer.parseInt(sc.nextLine());
        
         if (key==-5)
        	 break;
         
        bin2dSearch(arr,key);
        
        }
        sc.close();
	}

	public static void bin2dSearch(int[][] arr,int key)
	{
		int n,curr;
		
		n=arr.length-1;
		//this resembles binary search in the sense that each comparision guarentees
		//the elimination of a significant number of eliminates from the searches
		//scope. In a good elimination, a row or a column will be eliminated.
	
		//start from the top right corner. Why a corner? Because then we wont need
		//to worry about the other side and a complete row or a column will be eliminated.
		//if we start in the middle the cut made will not eliminate a complete row and
		// we may miss out on some elements.
		
		//curr=arr[0][n-1];
		
		int i=0,j=n;
		
		while(i<=n && j>=0 )
		{
			curr=arr[i][j];
			if (curr==key)
				{System.out.println("Key found at:"+i+" "+j);
				 break;
				}
			
			if (curr>key)  //the row below cant possibly have the key, so we might as well eliminate the row.
				j--;
			
			else
				i++;
		}
		
		if (i>n || j<0)
			System.out.println("Key not found");
	}
	
	public static void showArray(int[][] arr)
	{
		for(int i=0;i<arr.length;i++)
        {
        	for(int j=0;j<arr.length;j++)
        		System.out.print(arr[i][j]);
        		
                System.out.println();	
        }
	}
}
