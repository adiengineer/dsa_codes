import java.util.Scanner;

public class Tester 
{

	public static void main(String[] args) 
	{
        Scanner sc=new Scanner(System.in);
		
		int n,k;
        
        n=Integer.parseInt(sc.nextLine());
        int[] arr=new int[n];
        
        ///arr formed.
        for(int i=0;i<n;i++)
          arr[i]=Integer.parseInt(sc.nextLine());
        
        show(arr);
        
        //test. ok  
        System.out.println(findInversions(arr));
        
        //now we need to get the req no of inversions.
        
        k=Integer.parseInt(sc.nextLine());
        
        arr=setInversions(arr,k);
        
        show(arr);
        System.out.println(findInversions(arr));
        
        sc.close();
        //now we need a method to find number of inversions.
	}

	public static int findInversions(int[] arr)
	{
	    //since we anyway are okay with bubble sort's O(n^2) here inversion 
		//algo too can have O(n^2) complexity.
		int inversions=0;
		
		for(int i=0;i<arr.length-1;i++)
		{
			for(int j=i+1;j<arr.length;j++)
				{   
				   if (arr[i]>arr[j])
					   inversions++;
				}
					
		}
		
		return inversions;
	}
	
	public static int[] setInversions(int[] arr,int k)
	{
	     int initialinv=findInversions(arr);
	     int size=arr.length,temp;
	     
	     //if k is more then need to increase the inversions, else need to decresase inversions.
	     
	     
	    
	     int currinv=initialinv;
	     if (k>initialinv)
	     {
	        // we need to create more inversions. Due to the nature of the swap which is ony
	    	//between adjacent elements, for each swap invcount only increases by 1.
	    	 
	    	 for(int i=0;i<size;i++)
	    	 {
	    		 for(int j=0;j<size-i-1;j++)
	    		 {
	    			    if (arr[j]<arr[j+1])
	    			    {
	    			    	temp=arr[j];
	    			    	arr[j]=arr[j+1];
	    			    	arr[j+1]=temp;
	    			    	currinv++;
	    			    	
	    			    	if (currinv==k)
	    			    		return arr;
	    			    }
	    		 }
	    	 }
	     }
	     
	     else  //if inversions are to be decreased.
	     {
	    	 for(int i=0;i<size;i++)
	    	 {
	    		 for(int j=0;j<size-i-1;j++)
	    		 {
	    			    if (arr[j]>arr[j+1])
	    			    {
	    			    	temp=arr[j];
	    			    	arr[j]=arr[j+1];
	    			    	arr[j+1]=temp;
	    			    	currinv--;
	    			    	
	    			    	if (currinv==k)
	    			    		return arr;
	    			    }
	    		 }
	    	 }
	     }
	     
	     
	        System.out.println("No change needed");
	         return arr;
	        
	}
	
	public static void show(int[] arr)
	{
		for(int i=0;i<arr.length;i++)
			System.out.print(arr[i]);
		
		System.out.println();
	}
}
