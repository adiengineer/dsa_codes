import java.util.Scanner;

public class Tester 
{
    
	public static void main(String[] args) 
	{
Scanner sc=new Scanner(System.in);
		
		int size;
		
		//take size from user.
		size=Integer.parseInt(sc.nextLine());
		
		int[] arr=new int[size];
		
		//create required array
		for(int i=0;i<size;i++)
			arr[i]=Integer.parseInt(sc.nextLine());
		
        //now find max and min at the same time.
		
		int [] maxarr=new int[size/2];
		int [] minarr=new int[size/2];
		int maxlast=-1,minlast=-1;
		
		//if even
		if (arr.length%2==0)
		{
           for(int i=0;i<=arr.length-2;i=i+2)
           {
        	   if (arr[i]>arr[i+1])
        	   {
        		   maxlast++;
        		   minlast++;
        		   maxarr[maxlast]=arr[i];
        		   minarr[minlast]=arr[i+1];
        	   }
        	   
        	   else
        	   {
        		   maxlast++;
        		   minlast++;
        		   maxarr[maxlast]=arr[i+1];
        		   minarr[minlast]=arr[i];
        	   }
           }
           
           //this will split elements in two arrays.
           int max=-5;
           int min=65536;
           for(int i=0;i<maxarr.length;i++)
           {
        	   if (maxarr[i]>max)
        	   {
        		   max=maxarr[i];
        	   }
           }
           System.out.println("Max element will be:"+max);
           
           for(int i=0;i<minarr.length;i++)
           {
        	   if (minarr[i]<min)
        	   {
        		   min=minarr[i];
        	   }
           }
           System.out.println("Min element will be:"+min);
		}
	
		
		if (arr.length%2!=0)
		{
           int extra=arr[arr.length-1];
			for(int i=0;i<=arr.length-3;i=i+2)
           {
        	   if (arr[i]>arr[i+1])
        	   {
        		   maxlast++;
        		   minlast++;
        		   maxarr[maxlast]=arr[i];
        		   minarr[minlast]=arr[i+1];
        	   }
        	   
        	   else
        	   {
        		   maxlast++;
        		   minlast++;
        		   maxarr[maxlast]=arr[i+1];
        		   minarr[minlast]=arr[i];
        	   }
           }
           
           //this will split elements in two arrays.
           int max=-5;
           int min=65536;
           for(int i=0;i<maxarr.length;i++)
           {
        	   if (maxarr[i]>max)
        	   {
        		   max=maxarr[i];
        	   }
           }
           if (max>extra)
           {System.out.println("Max element will be:"+max);
           }
           else
        	   System.out.println("Max element will be:"+extra);
           
           for(int i=0;i<minarr.length;i++)
           {
        	   if (minarr[i]<min)
        	   {
        		   min=minarr[i];
        	   }
           }
           
           if (min<extra)
           System.out.println("Min element will be:"+min);
           else
        	   System.out.println("Min element will be:"+extra);
		}
	}

}
