import java.util.Scanner;


public class Tester 
{

	public static void main(String[] args) 
	{
Scanner sc=new Scanner(System.in);
		
		int size;
				
				//take size from user.
				size=Integer.parseInt(sc.nextLine());
				
				int[] arr=new int[size];
				
				//create required array
				for(int i=0;i<size;i++)
					arr[i]=Integer.parseInt(sc.nextLine());
				
				insertionsort(arr);
				sc.close();

	}

	public static void insertionsort(int[] arr)
	{
		int j,curr;
		for(int i=1;i<arr.length;i++)
		{  
			curr=arr[i];
			j=i-1;
			
			while (j>=0 && arr[j]>curr)
			{
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=curr;
		}
		
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
}
