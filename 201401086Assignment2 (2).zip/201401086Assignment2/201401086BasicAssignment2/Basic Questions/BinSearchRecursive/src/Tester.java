import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		int size,key;
		
		//take size from user.
		size=Integer.parseInt(sc.nextLine());
		
		int[] arr=new int[size];
		
		//create required array
		for(int i=0;i<size;i++)
			arr[i]=Integer.parseInt(sc.nextLine());
		
		//now take in key,
		
		key=Integer.parseInt(sc.nextLine());
		
		recBinSearch(arr,key,0,size-1);
		
		sc.close();

	}
     
	
	public static void recBinSearch(int[] arr,int key,int i,int j) //array indices.
	{
        int middle;
		//base case.
		if (i>j)
		{
			System.out.println("Key not found");
			return; //-5 indicates error.
		}
		
	    //otherwise search by comp in middle	
		
	    middle=(i+j)/2;
	   
	     if (arr[middle]==key)
	     {
	          System.out.println("Key found at index:"+middle);  //index where it is found.  	 
	     }
	     
	     if (arr[middle]<key)
	    	 recBinSearch(arr,key,middle+1,j);
	     
	     if (arr[middle]>key)
	    	 recBinSearch(arr,key,i,middle-1);
	}
}
