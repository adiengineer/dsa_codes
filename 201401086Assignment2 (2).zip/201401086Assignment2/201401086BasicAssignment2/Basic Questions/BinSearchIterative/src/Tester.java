import java.util.Scanner;


public class Tester 
{

	public static void main(String[] args) 
	{
Scanner sc=new Scanner(System.in);
		
		int size,key;
		
		//take size from user.
		size=Integer.parseInt(sc.nextLine());
		
		int[] arr=new int[size];
		
		//create required array
		for(int i=0;i<size;i++)
			arr[i]=Integer.parseInt(sc.nextLine());
		
		//now take in key,
		
		key=Integer.parseInt(sc.nextLine());
		
	   IteBinSearch(arr,key,0,size-1);
		
		sc.close();

	}

	
	public static void IteBinSearch(int[] arr,int key,int i,int j)
	{
		int middle;
		
		   while(i<=j)
		   {
		        middle=(i+j)/2; //this is the mid index.
		        
		        if (arr[middle]==key)
		        {
		        	System.out.print("Key found at: "+middle);
		        	break;
		        }
		        
		       if (arr[middle]<key)
		    	   i=middle+1;
		       
		       if (arr[middle]>key)
		    	   j=middle-1;
		   }
		   
		   if (i>j)
			   System.out.println("Key not found");
	}
}
