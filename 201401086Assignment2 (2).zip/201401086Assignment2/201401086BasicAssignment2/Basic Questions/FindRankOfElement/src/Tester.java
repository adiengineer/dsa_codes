import java.util.Arrays;
import java.util.Scanner;


public class Tester
{

	public static void main(String[] args) 
	{
Scanner sc=new Scanner(System.in);
		
		int size,key;
		
		//take size from user.
		size=Integer.parseInt(sc.nextLine());
		
		int[] arr=new int[size];
		
		//create required array
		for(int i=0;i<size;i++)
			arr[i]=Integer.parseInt(sc.nextLine());
		
		//now take in key,
		
	 	key=Integer.parseInt(sc.nextLine());
   
	   findRank(arr,key);	
	   sc.close();
		
	}

	//find rank of this key in array.
	public static void findRank(int[] arr,int key)
	{
	   boolean found=false; //this is to check if element is present or not.
	   int rank=0;
	   
	   //traverse through the array.  
	   for(int i=0;i<arr.length;i++)
	     {
	    	 if (arr[i]==key)
	    		 found=true; //element present.
	    	 
	    	 if (arr[i]<key)
	    		 rank++;
	     }
	   
	     if (found==false)
	    	 System.out.println("Key not present in the array");
	     else
	     {    rank++;
	    	 System.out.println("Rank of given key:"+rank);
	     }
	}
	
}
