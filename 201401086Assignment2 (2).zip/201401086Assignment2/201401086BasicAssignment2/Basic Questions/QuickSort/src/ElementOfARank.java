import java.util.Scanner;


public class ElementOfARank 
{
	public static void main(String[] args) 
	{
		
Scanner sc=new Scanner(System.in);
		
		int i,size,rank,count=0,curr=-5;
				
				//take size from user.
				size=Integer.parseInt(sc.nextLine());
				
				int[] arr=new int[size];
				int[] sortedarray= new int[size];
				
				//create required array
				for(int j=0;j<size;j++)
					arr[j]=Integer.parseInt(sc.nextLine());
				
				sortedarray=quicksort(arr,0,arr.length-1);
				 
				//find element of this rank,
				rank=Integer.parseInt(sc.nextLine());
				 
				//search for the required element 
				for(i=0;i<sortedarray.length;i++)
				 {
					 if (sortedarray[i]>curr)
						 {count++;
						  curr=sortedarray[i];
						 }
					 
					 if (count==(rank-1))
						 break;
				 }
				 
				 System.out.print("Required element is:"+arr[i+1]);
			     System.out.println();
				sc.close();
      
	}
	
	
	public static int[] quicksort(int[] arr,int left,int right)
	{
		int pivot,temp;
		int i=-1,j;
		
		//base case
		if (left>right)
			{
			   
			
			 
			
			  return arr; //it means subproblem has finished.
	        }
		
		//now partition the array.
           		
		pivot=arr[right]; //the last element
		
		for( j=0;j<right;j++)
		{
			if (arr[j]<=pivot)
			{
				i++;
				
				//exchange unwanted element with arr[j]
				temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
		//finally put the pivot in place.
		
		temp=arr[right];
		arr[right]=arr[i+1];
		arr[i+1]=temp;
		
		//now  the array is partitioned, so call quicksort recursively on smaller 
		//arrays to partition them.
		
		quicksort(arr,left,i);
		quicksort(arr,i+2,right);
		
		return arr;
	}
}
