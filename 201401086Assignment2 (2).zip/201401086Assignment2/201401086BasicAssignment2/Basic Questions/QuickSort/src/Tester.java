import java.util.Scanner;


public class Tester
{

	public static void main(String[] args) 
	{
		
Scanner sc=new Scanner(System.in);
		
		int size;
				
				//take size from user.
				size=Integer.parseInt(sc.nextLine());
				
				int[] arr=new int[size];
				int[] sortedarray= new int[size];
				
				//create required array
				for(int i=0;i<size;i++)
					arr[i]=Integer.parseInt(sc.nextLine());
				
				sortedarray=quicksort(arr,0,arr.length-1);
				 
				for(int i=0;i<sortedarray.length;i++)
					System.out.print(arr[i]+" ");
				
				System.out.println();
				sc.close();
      
	}
	
	public static int[] quicksort(int[] arr,int left,int right)
	{
		int pivot,temp;
		int i=-1,j;
		
		//base case
		if (left>right)
			{
			   
			
			 
			
			  return arr; //it means subproblem has finished.
	        }
		
		//now partition the array.
           		
		pivot=arr[right]; //the last element
		
		for( j=0;j<right;j++)
		{
			if (arr[j]<=pivot)
			{
				i++;
				
				//exchange unwanted element with arr[j]
				temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
		//finally put the pivot in place.
		
		temp=arr[right];
		//System.out.println(arr[right]+" "+arr[i+1]);
		arr[right]=arr[i+1];
		arr[i+1]=temp;
		
		//now  the array is partitioned, so call quicksort recursively on smaller 
		//arrays to partition them.
		
		quicksort(arr,left,i);
		quicksort(arr,i+2,right);
		
		return arr;
	}

}
