import java.util.Scanner;


public class Tester 
{

	public static void main(String[] args)
	{
		//I have a partition routine. Now do the housekeeping stuff.
		
Scanner sc=new Scanner(System.in);
		
		int size,rank;
				
				//take size from user.
				size=Integer.parseInt(sc.nextLine());
				
				int[] arr=new int[size];
				//int[] sortedarray= new int[size];
				
				//create required array
				for(int i=0;i<size;i++)
					arr[i]=Integer.parseInt(sc.nextLine());
				
				//scan rank
				rank=Integer.parseInt(sc.nextLine());
				
			//now write code for finding ele of given rank.
				
		  findrank(arr,rank-1,0,arr.length-1);		
				sc.close();
	}
	
	public  static int partition(int [] arr,int left,int right)
	{ 
		//finally return the pos of pivot. As that will be its rank
		
		int i=-1,pivot,j,temp;
		
		 //then the required rank is rank present.
		
		
		pivot=arr[right];
		

		for( j=0;j<right;j++)
		{
			if (arr[j]<=pivot)
			{
				i++;
				
				//exchange unwanted element with arr[j]
				temp=arr[j];
				arr[j]=arr[i];
				arr[i]=temp;
			}
		}
		

		temp=arr[right];
		//System.out.println(arr[right]+" "+arr[i+1]);
		arr[right]=arr[i+1];
		arr[i+1]=temp;
		
		//now pivot is in its correct place. So its pos=rank.
		
		return (i+1);
	}
	
	public static void findrank(int [] arr,int rank,int left,int right)
	{
		int positionofpivot;
		
		if (left>right)
		  {
			  System.out.println("No such element present");
			  return;
		  }
		  
		  positionofpivot=partition(arr,left,right);
		  
		  if (positionofpivot==(rank))  //change
		  {
			  System.out.print("Element required: "+arr[positionofpivot]);
			  return;
		  }
		  
		  //must look to the left
		  if (positionofpivot>rank)
			  findrank(arr,rank,left,positionofpivot-1);
		  if (positionofpivot<rank)
			  findrank(arr,rank,positionofpivot+1,right);
			  
	}
}

