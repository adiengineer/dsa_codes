import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		// routone for returning relatives of an element in an heap
		Scanner sc=new Scanner(System.in);
        int size,heapsize;
        
        size=Integer.parseInt(sc.nextLine());
        heapsize=Integer.parseInt(sc.nextLine());;
        int[] heap=new int[heapsize];
        //take in the heap(assume correct in the form of an array)
        if(heapsize>size)
        	System.out.println("Check heapsize limit");
        
        else
        {
        	//if correct take in heap values
        	for(int i=0;i<heapsize;i++)
        	   heap[i]=Integer.parseInt(sc.nextLine());
        	
        	recover(heap,Integer.parseInt(sc.nextLine()));
        }
        
        sc.close();
	}

	
	public static void recover(int[] heap,int i)
	{
		if (i==0)
		{
			System.out.println("Left child is: "+heap[1]);
			System.out.println("Right child is: "+heap[2]);
			return;
		}
		if (2*i<heap.length)
			System.out.println("Left child is: "+heap[2*i]);
		if ((2*i+1)<heap.length)
			System.out.println("Right child is: "+heap[(2*i)+1]);
		
		System.out.println("Parent is: "+heap[i/2]);
	}
}
