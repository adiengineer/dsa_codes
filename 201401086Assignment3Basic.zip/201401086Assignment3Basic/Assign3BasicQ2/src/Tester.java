import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		// first implement heapify and then build heap.
		
		//first do routine work to take in a incorrect heap which neads to be
		//heapified.
		
		Scanner sc=new Scanner(System.in);
        int size,heapsize;
        
        size=Integer.parseInt(sc.nextLine());
        heapsize=Integer.parseInt(sc.nextLine());;
        int[] heap=new int[heapsize];
        //take in the heap(assume correct in the form of an array)
        if(heapsize>size)
        	System.out.println("Check heapsize limit");
        
        else
        {
        	//if correct take in heap values
        	for(int i=0;i<heapsize;i++)
        	   heap[i]=Integer.parseInt(sc.nextLine());
            	
        //now test the heapify routine, it assumes that lhs,rhs sub is correct and 
        //tries to correct the problem at i.
        	
        	//heap=heapify(heap,Integer.parseInt(sc.nextLine()));
        	//heap=buildheap(heap);
        	
        	//build heap is also okay. Now test heapsort.
        //	heap=heapsort(heap,heap.length-1);
        	
        	//check buildrootdown
        	
        	buildrootdown(heap);
        	showheap(heap);
        }
  
	}

	public static int[] heapify(int[] heap,int i,int buildtill)
	{
		int temp;
		//i is where the problem exists, if corect i is given
		// it will simply break out.
		//assumption is that arr memory is equal to heap size.
		
		//continue till it has a left child.
		while (2*i+1<buildtill)
		{
			if (heap[i]>=heap[2*i+1] && heap[i]>=heap[2*i+2]) //no problem exists.
				break;
			
			//if problem exists then decide which direction to swap
			//now if right child is not present then have to go to left.
			if (2*i+2>buildtill)
			{
				//swap with left child
				temp=heap[i];
				heap[i]=heap[2*i+1];
				heap[2*i+1]=temp;
				i=2*i+1;
			}
			
			else //if right child exists have to compare two. 
			{
				if (heap[2*i+1]>=heap[2*i+2])
				{
					//swap with left
					temp=heap[i];
					heap[i]=heap[2*i+1];
					heap[2*i+1]=temp;
					i=2*i+1;
				}
				else
				{
					//swap with right
					temp=heap[i];
					heap[i]=heap[2*i+2];
					heap[2*i+2]=temp;
					i=2*i+2;
				}
			}
		}
		
		return heap;
	}
	
	public static void showheap(int[] heap)
	{
		for(int i=0;i<heap.length;i++)
			System.out.print(heap[i]+" ");
		System.out.println();
	}
	
	//this gives us control over till where is heap bulding is done.
	public static int[] buildheap(int[] heap,int buildtill)
	{
		//this is from down to up.
		
		//do the swapping and then return the result.
		for(int i=buildtill;i>=0;i--)
		{
			heapify(heap,i,buildtill);
		}
		
		return heap;
	}
	
	public static int[] heapsort(int[] heap,int buildtill)
	{
	       int temp;
		while (buildtill>=0)
	       {
	    	    heap=buildheap(heap,buildtill); //was not overwritting.
	    	    
	    	    //then swap and decrement buildtill
	    	  
	    	    
	    	    //swap first element with element at buildtill
	    	    temp=heap[buildtill];
	    	    heap[buildtill]=heap[0];
	    	    heap[0]=temp;
	    	    
	    	    buildtill--; //ensuring breakage.
	       }
		
		return heap;
	}
	
	
	public static int[] buildrootdown(int[] heap)
	{
		//run for all n elements.
		for(int i=0;i<heap.length;i++)
		{
			//for each element continue to bubble it up
			//till it is the root or is lesser than parent
			
			int j=i,temp;
			
			//while not root or it is less
			while(j>0 && heap[j]>heap[(j-1)/2])
			{
				temp=heap[j];
				heap[j]=heap[(j-1)/2];
			    heap[(j-1)/2]=temp;
			    
			    j=(j-1)/2;
			}
		}
		
		return heap;
	}
}
