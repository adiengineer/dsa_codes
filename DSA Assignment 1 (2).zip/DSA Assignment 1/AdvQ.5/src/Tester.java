import java.util.Scanner;

public class Tester 
{
    public static void main(String[] args)
    {
    	Scanner sc=new Scanner(System.in);
    	
    	LinkList l=new LinkList();
    	
    	for(int i=0;i<10;i++)
    	 {
    		l.insert(Integer.parseInt(sc.nextLine()));
    		l.show();
    	 }
    	
    	for(int i=0;i<5;i++)
    	{
    		LinkList searchResult=l.searchKey(Integer.parseInt(sc.nextLine()));
    		searchResult.show();
    	}
    	sc.close();
    }
}

