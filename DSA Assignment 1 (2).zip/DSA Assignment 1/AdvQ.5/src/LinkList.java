public class LinkList 
{
	
	//here I just need to insert elements into the linked list.
	Node head=null;
	Node tail=null;
	   public void insert(int a)//queue composes of a set of nodes 
	      {if (head==null)
	          { head=new Node();
	    	     head.setData(a);
	    	     tail=head;
	    	     head.setNext(null);
	   // 	     size++;
	          }
	      
	      else
	          {  tail.setNext(new Node());
	    	         tail.getNext().setData(a);
	    	         tail=tail.getNext();
	    	         tail.setNext(null);
	    //	         size++;
	          }
	    	  
	     }//insert at the tail of the queue.

	   
	   //search for a particular key and return all eleements which match the key as a ll
	   public LinkList searchKey(int key)
	   {
		  Node temp=head;
		  LinkList matchList=new LinkList();
		  
		  //traverse through the list. if element matching the key is found
		  //put it in the new ll.
		  while(temp!=null)
		  {
			 if (temp.data==key)
			 {
				 matchList.insert(temp.data);
			 }
			 
			 temp=temp.next;
		  }
		  
		 return matchList; 
	   }
	   
	   public void show()
	      { Node curr=head; 
	    	    
	      if (head==null)
	      System.out.println("Search List is empty");
	      
	      else
	      { 
	    	  while(curr!=null)
	    	    {  System.out.print(curr.getData()+" ");
	    	    	curr=curr.getNext();
	    	    }
	    	    System.out.println();
	      }    
	      }
}