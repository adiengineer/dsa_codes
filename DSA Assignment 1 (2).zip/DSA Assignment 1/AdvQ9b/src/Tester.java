import java.util.Scanner;
public class Tester
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		//now code to permute elements in the stack.
		
		//create the stack.
		
		Stack s=new Stack();
		
		//auxillary stacks.
		Stack s1=new Stack();
		Stack s2=new Stack();
		
		for(int i=0;i<5;i++) // 5 is for example. can take any size.
		{
		    s.push(Integer.parseInt(sc.nextLine()));
		    
		}
		
		s.show();

		//now take in permu in form of string.
		String permu=sc.nextLine();
		 
		 if (permu.length()!=5)
			 {System.out.println("Permutation is wrong");
			 sc.close();
			  return;
			 }
		//now write code for permuting the stack.
		
		int element;
		
		
		while(s.size>0)
		{
			element=s.pop();
			
			// if not required 
			if (element!=(permu.charAt(0)-48))
				 s2.push(element);
			else
				s1.push(element);
		}
		
		if (s1.size==0)
			{System.out.println("Permutation entered is wrong");
			sc.close();
			return;
			}
		//first element pushed
		s.push(s1.pop());
		
		for(int i=1;i<permu.length();i++)
		{
			int sizeofori=s.size; 
			if (s1.size==0)
			 {
				   while(s2.size>0)
				   {
					   element=s2.pop();
					   if (element==(permu.charAt(i)-48))
						   s.push(element);
					   else
						   s1.push(element);
				   }
			 }
			 
			 if (s2.size==0)
			 {
				   while(s1.size>0)
				   {
					   element=s1.pop();
					   if (element==(permu.charAt(i)-48))
						   s.push(element);
					   else
						   s2.push(element);
				   }
			 }
			 
			 if(sizeofori==s.size)
			 {
				 System.out.println("Permutation is wrong");
				 sc.close();
				 return;
			 }
		}
		
		s.show();
		sc.close();
		
	}

}
