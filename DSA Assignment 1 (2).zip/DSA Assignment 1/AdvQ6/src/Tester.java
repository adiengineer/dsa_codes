import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		
		//create the dll.
		DoublyLL dl=new DoublyLL();
      
		//add 10 elements.
		for(int i=0;i<10;i++)
		{
			dl.insert(Integer.parseInt(sc.nextLine()));
			dl.show();
		}
	//	dl.showRev(); //check
		
		if(dl.reverseSub(2,5)!=-5)
			{dl.show();
			 dl.showRev();
			}
		else
		System.out.println("Check the range!");
			
		
		//insertion done now, add the func for reversal of sub between the required indices.
		sc.close();
	}

}
