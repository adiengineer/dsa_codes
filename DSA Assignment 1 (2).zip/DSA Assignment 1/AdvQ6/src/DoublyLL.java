
public class DoublyLL 
{
     Node head=null;
     Node tail=null;
     int size=0;
     public void insert(int x)
     {
    	 //if list is empty
    	 if (head==null)
    	 {
    		 head=new Node(x);
    		 head.next=null;
    		 tail=head;
    		 head.prev=null;
    		 size++;
    	 }
    	 
    	 else
    	 {
    		 tail.next=new Node(x);
    		 tail.next.prev=tail; // back path made.
    		 tail=tail.next;
    		 tail.next=null;
    		 size++;
    	 }
     }
     
     public void show()
     {
    	 Node curr=head;
    	 
    	 while(curr!=null)  //very silly mistake I had included head instead of curr.
    	 {
    		 System.out.print(curr.x+" ");
    		 curr=curr.next;
    	 }
    	 System.out.println();
     }
     
     //I will treat a,b as zero indexed. So it must be from 0 to n-1.
     public int reverseSub(int l,int r)
     {
    	Node a=head,b=head,aan,bbn;
    	 
    	 //If indices are not proper.
    	   if (!(l>=0 && l<=size-1 && r>=0 && r<=size-1 && l<r) ) //should be l<r as equal to is redundunt.
    		   return -5; //indicates error.
    	   
    	   //if indices are proper then set up pointers at those points.
    	   
    	   //drag a by l. 
    	   for(int i=1;i<=l;i++)
    	       a=a.next;
    	   
    	   //drag b by r
    	   for(int i=1;i<=r;i++)
    	       b=b.next;
    	   
    	   //nodes right 
    	   aan=a.next;
    	   bbn=b.prev;
    	   
    	  // now implement the actual rev.
    	  //start with the nodes right before and after the sequence. 
    	   if (a.prev!=null)
    	   a.prev.next=b;
    	   else
    	   {
    		   head=b;
    		   head.prev=null;
    	   }
     	   
    	   if(b.next!=null)
     	   b.next.prev=a;
     	   else
     	   {
     		   tail=a;
     		   tail.next=null;
     	   }
    	   
    	 //now reverse both pointers of the interim nodes. //check if starting from the next node works.
    	   Node curr=aan,temp;
           	   
    	    while(curr!=b) //
    	    {
    	       temp=curr.next;
    	       curr.next=curr.prev;
    	       curr.prev=temp;
    	       curr=temp;
    	    }
    	    
    	    //these two changes, when I made later the code worked. This was because I had changed a next and hence it
    	    //was flying over b and running on null thus leading to npe.
    	    b.prev=a.prev; 
    	    a.next=b.next;
    	    
    	    //last two changes.
    	    b.next=bbn;
    	    a.prev=aan;
    	    
    	    return 0; //indicates completion.
     }
     
     public void showRev()
     {
 Node curr=tail;
    	 
    	 while(curr!=null)  //very silly mistake I had included head instead of curr.
    	 {
    		 System.out.print(curr.x+" ");
    		 curr=curr.prev;
    	 }
    	 System.out.println();
     }
}
