import java.util.Scanner;
public class Main {

	//class attribute
	
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		LinkList l=new LinkList();	
		Node temp,prev,temp1;
        
        //add 10 integers to the ll.
        for(int i=0;i<2;i++)
        {
        	l.insert(Integer.parseInt(sc.nextLine()));
        }
        
        l.show();
        //code for reversal.
        
        if (l.head==null)
        	System.out.println("First fill something to reverse it.");
        
        else if (l.head.next==null)
        	System.out.println("No need to reverse");
        
        else if (l.head.next.next==null)
        {
        	 temp=l.head.next;
        	l.head.next=null;
        	temp.next=l.head;
        	l.head=temp;
        	l.show();
        }
        
      
        
        else   if (l.head.next==null)
        	System.out.println("No need to reverse");
        
        //all strange cases handled.
        
        else
        {
        	//to get prev,next in correct posiitons and to make head as ending null
        	temp=l.head.next.next;
        	prev=l.head.next;
        	prev.next=l.head;
        	l.head.next=null;
        	
        	//then repreat this till end.
        	while(temp!=null)
        	{
        		temp1=temp.next;
        		temp.next=prev;
        		prev=temp;
        		temp=temp1;
        	}
        	
        	//at the end of the loop prev should end up at the last node which should be the new head.
        	l.head=prev; 
        	//the ll hopefully is reversed. Now let us check.
        	
        	l.show();
        	sc.close();
        }
	}

	

}
