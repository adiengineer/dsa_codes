
public class BehaviouralContainer 
{
	//implement it as a linklist.
   Node head=null;
   Node tail=null,prev=null;
   
   //this is critical in the given q.
   int size=0;
   
   //specify the behaviour.
   //no condiiton has been stated on deletion, so deletion assume to be the same in both, insert at end.
    
   //insertion done
   public void insert(int a)
   {
	   if (head==null)
       { head=new Node();
 	     head.setData(a);
 	     tail=head;
 	     head.setNext(null);
 	     size++;
       }
   
   else
       {  tail.setNext(new Node());
 	         tail.getNext().setData(a);
 	         prev=tail;
 	         tail=tail.getNext();
 	         tail.setNext(null);
 	         size++;
       }   
   }
   
   //way the elements are removed will depend on the size of the data structure.
   
   public int delete()
   {
	   int element;
	   Node temp=head;
	   if (size<=0)
	      return -5; //signifying error.
	   
	   if (size<=8)
	   {
		   //then behave as a queue, hence delete like a queue.
		   //make first node invalid by orphaning it by giving its reference to the next node.
		   element=head.data;
		   head=head.next;
		   size--;
		   return element;
	   }
	   
	   //otherwise, delete like a stack.
	   //is there a problem here. I think there was a problem at l 58 when just one node was left, but now this will not
	   //happen as the deletion at the end is requried only when we have more 8 elements in the DS.
	   element=tail.data;
	   
	   while(temp.next!=tail)
		   temp=temp.next;
	   
	    tail=temp;
	    tail.next=null;  //thereby deleting the last element hence pop.
	   //tail=prev; //why does prev method work?
	   size--;
	   return element;
   }
   
   public void show()
   { Node curr=head; 
 	    while(curr!=null)
 	    {  System.out.print(curr.getData()+" ");
 	    	curr=curr.getNext();
 	    }
 	    System.out.println();
 	    System.out.println("Current size "+ size);
   }
}
