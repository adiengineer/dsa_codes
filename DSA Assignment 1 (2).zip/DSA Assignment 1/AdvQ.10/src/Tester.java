import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		int checker;
		//create the DS
		BehaviouralContainer b=new BehaviouralContainer();
		
		//insert the elements
		for(int i=0;i<16;i++)
		{b.insert(Integer.parseInt(sc.nextLine()));
		  b.show();
		}	
		
		for(int i=0;i<20;i++)
		{  checker=b.delete();
		  if (checker!=-5)
		  b.show();
		  else
			System.out.println("The DS is empty.");  
		}
	}

}
