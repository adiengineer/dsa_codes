import java.util.Scanner;

public class Tester 
{

	public static void main(String[] args)
	{
	  Scanner sc=new Scanner(System.in);
	  
		int index1,index2;
	  //q created
		Queue q=new Queue();
		 
		//the temperory queues.
        Queue q1=new Queue();
        Queue q2=new Queue();
        
		//fill in the queue elements.
		
		for(int i=0;i<10;i++)
		{
			q.insert(Integer.parseInt(sc.nextLine().trim()));
		}
		q.show();
		
		//now scan the indexes at which reversal should happen.
		
		index1=Integer.parseInt(sc.nextLine().trim());
		index2=Integer.parseInt(sc.nextLine().trim());
		
		//handle errors
		if (index1<0 ||index2<0 ||index1>=q.size ||index2>=q.size)
			System.out.println("Please input valid indices");
		
		else
		{
			//write code for reversal.
			
			int limit=q.size;
			for(int i=0;i<limit;i++)
			{
				if (i!=index1 && i!=index2)
				{
					q1.insert(q.delete());
				}
				else
				{
					q2.insert(q.delete());
				}
			}
			
			//reverse elements in q2.
			//reverse the order.
			q2.insert(q2.delete());
			
			for(int i=0;i<limit;i++)
			{
				if (i!=index1 && i!=index2)
				{
					q.insert(q1.delete());
				}
				else
				{
					q.insert(q2.delete());
				}
			}
			q.show();
		}
	}

}
