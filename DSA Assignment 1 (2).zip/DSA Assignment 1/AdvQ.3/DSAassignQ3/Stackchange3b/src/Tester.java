import java.util.Scanner;


public class Tester {

	public static void main(String[] args)
	{
		// reverse contiguous subsequencce
		int upperin,lowerin,size;
		Scanner sc=new Scanner(System.in);
		
		//scan size
		size=Integer.parseInt(sc.nextLine().trim());
		Stack stk=new Stack(size);
		
        Stack tempstk=new Stack(size);
        
        //filling elements in the stack.
        for(int i=0;i<size;i++)
        	stk.push(Integer.parseInt(sc.nextLine()));
        
         stk.show();
         
         upperin=Integer.parseInt(sc.nextLine());
         lowerin=Integer.parseInt(sc.nextLine());
         
         //all error cases handled.
         if (upperin<0 || upperin>size)
	    	  System.out.println("Illegal upper index");
	     if (lowerin<0 || lowerin>size)
	    	  System.out.println("Illegal lower index");
	     if (lowerin>upperin)
	    	  System.out.println("Please check index order");
	     if (lowerin==upperin)
	    	 System.out.println("Nothing to be changed");
	     
	     //code for reversing the subsequence.
	     
	     else
	     {
	    	int pointer=0;
	    	 //this will hold the elements to be reversed.
	    	 int[] storearr=new int[(upperin-lowerin)+1];
	    	 
	    	 for(int i=0;i<=(size-1);i++)
		       {
		    	   if (i>upperin || i<lowerin)
		    	   {
		    		  tempstk.push(stk.pop());
		    	   }
		    	   
		    	   else
		    	   {
		    		   //push in storarr
		    		   storearr[pointer]=stk.pop();
		    		   pointer++;
		    	   }
		      }
	    	 
	    	   pointer=0;
	    	 //actual code for reversal.
	    	 for(int i=0;i<=(size-1);i++)
	    	 {
	    		 if ((i>upperin || i<lowerin))
	    			 stk.push(tempstk.pop());
	    		 else
	    		  {
	    			 stk.push(storearr[pointer]);
	    			 pointer++;
	    		  }
	    	 }
	    	 
	    	 stk.show();
	     }
         
	}

}
