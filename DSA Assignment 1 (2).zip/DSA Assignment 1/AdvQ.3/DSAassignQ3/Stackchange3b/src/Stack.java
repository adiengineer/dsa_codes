
public class Stack 
{
   //stack using an array
	//predeterminded size.
	
	
	int size=10;
	
	//constructor
	
	Stack()
	{
		
	}
	
	Stack(int size)
	{ 
	  size=this.size;	
	}
	
	int[] stk=new int[size]; 
	
	
	int top=-1;
	public void push(int x)
	{
		if (top==(size-1))
		{
			System.out.println("Stack is full");
		}
		else
			{top++;
			 stk[top]=x;
			}
	}
	
	public int pop()
	{ 
		 int element;
	 	if (top<0)
	 		{ // System.out.println("Stack is empty");
	 		  return -100; //indicates that error exists.
	 		}
	 	else
	 	{
	 		element=stk[top];
	 		top--;
	 		return element;
	 	}
	}
	
	
	
	public void show()
	{
		for(int i=0;i<size;i++)
			System.out.print(stk[i]+" ");
		System.out.println();
	}
}