import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
        
		int left,right,t;
		Queue q=new Queue();
		
		//fill elements in queue
		//add a test case loop.
		
		t=Integer.parseInt(sc.nextLine());
		
		for(int i=0;i<10;i++)
			q.insert(Integer.parseInt(sc.nextLine()));
		
		    q.show();
		    
		//test case loop.
		for(int k=0;k<t;k++)
		{
		 
			//scan left right.
		left=Integer.parseInt(sc.nextLine());
		right=Integer.parseInt(sc.nextLine());
		
		Queue reversedQueue=reverseSubsequence(q,left,right);
		
		if(reversedQueue!=null)
			q.show();
		
		}
		sc.close();
	}

	
	//note that left,right are 0 indexed.
	public static Queue reverseSubsequence(Queue q,int left,int right)
	{
		int sizeOfQueue=q.size;
		Queue nullqueue=null; //null pointer, for handling errors.
						 //handle errors.
		
		if (left<0 || right>=sizeOfQueue)
			{System.out.println("Please check the range");
			 return nullqueue;
			}
		if (left>right)
		  {System.out.println("Please make sure that left<=right");
		  return nullqueue;
		  }
		if (left==right)
			{System.out.println("No work needed");
			return nullqueue;
			}
		
		else
			{//auxillary queues.
		Queue q1= new Queue();
		Queue q2=new Queue();
		
		//distribute elements in q1 and q2.
		for(int i=0;i<sizeOfQueue;i++)
		{
			//if part of the subsequence, put in q2. Here i,represents the order in which it is removed.
			if (i>=left && i<=right)
				q2.insert(q.delete());
			else
				q1.insert(q.delete());  //if not part of the subsequence.
		}
		
		// now do the reversal logic
		int sizeofQ2=q2.size; //imp variable.
		
		for(int i=0;i<sizeOfQueue;i++)
		{
			if (i>=left && i<=right)
			{
			    	for(int k=0;k<sizeofQ2-1;k++)
			    	{
			    		q2.insert(q2.delete()); //circular.
			    	}
			    	
			    	//now required element is available for removing.
			    	q.insert(q2.delete());
			    	sizeofQ2--;
			}
			
			else //simply pop back into q no need to change.
			{
				q.insert(q1.delete());
			}
		}
		
	      }
		return q;
	}
	
	//usually we had an object which was carrying out the duties. Here our main function is doing that job, so 
	//create function so that the code looks cleaner.
}
