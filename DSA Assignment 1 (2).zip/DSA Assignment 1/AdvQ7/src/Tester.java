import java.util.Scanner;


public class Tester 
{

	public static void main(String[] args) 
	{
Scanner sc=new Scanner(System.in);
		
		//create the dll.
		DoublyLL dl=new DoublyLL();
      int[] arr={0,7};
		 
		//add 10 elements.
		for(int i=0;i<9;i++)
		{
			dl.insert(Integer.parseInt(sc.nextLine()));
			dl.show();
		}

		//now check the method out.
		dl.reverse(arr,dl.head,dl.tail);
		dl.show();
		dl.showRev();
		sc.close();
	}

}
