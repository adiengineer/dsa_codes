

public class Node 
{
    int x;
    Node next=null;
    Node prev=null;
    
    //constructor when we create the list.   
    Node(int x)
       {
    	 this.x=x;  
       }
}
