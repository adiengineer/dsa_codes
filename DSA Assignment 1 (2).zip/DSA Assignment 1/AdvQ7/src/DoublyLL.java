

public class DoublyLL 
{
     Node head=null;
     Node tail=null;
     int size=0;
     public void insert(int x)
     {
    	 //if list is empty
    	 if (head==null)
    	 {
    		 head=new Node(x);
    		 head.next=null;
    		 tail=head;
    		 head.prev=null;
    		 size++;
    	 }
    	 
    	 else
    	 {
    		 tail.next=new Node(x);
    		 tail.next.prev=tail; // back path made.
    		 tail=tail.next;
    		 tail.next=null;
    		 size++;
    	 }
     }
     
     public void show()
     {
    	 Node curr=head;
    	 
    	 while(curr!=null)  //very silly mistake I had included head instead of curr.
    	 {
    		 System.out.print(curr.x+" ");
    		 curr=curr.next;
    		 
    		// System.out.println("stuck in show");
    	 }
    	 System.out.println();
     }
     
     //I will treat a,b as zero indexed. So it must be from 0 to n-1.
     public int reverseSub(int l,int r)
     {
    	Node a=head,b=head,aan,bbn;
    	 
    	 //If indices are not proper.
    	   if (!(l>=0 && l<=size-1 && r>=0 && r<=size-1 && l<r) ) //should be l<r as equal to is redundunt.
    		   return -5; //indicates error.
    	   
    	   //if indices are proper then set up pointers at those points.
    	   
    	   //drag a by l. 
    	   for(int i=1;i<=l;i++)
    	       a=a.next;
    	   
    	   //drag b by r
    	   for(int i=1;i<=r;i++)
    	       b=b.next;
    	   
    	   //nodes right 
    	   aan=a.next;
    	   bbn=b.prev;
    	   
    	  // now implement the actual rev.
    	  //start with the nodes right before and after the sequence. 
    	   if (a.prev!=null)
    	   a.prev.next=b;
    	   else
    	   {
    		   head=b;
    		   head.prev=null;
    	   }
     	   
    	   if(b.next!=null)
     	   b.next.prev=a;
     	   else
     	   {
     		   tail=a;
     		   tail.next=null;
     	   }
    	   
    	 //now reverse both pointers of the interim nodes. //check if starting from the next node works.
    	   Node curr=aan,temp;
           	   
    	    while(curr!=b) //
    	    {
    	       temp=curr.next;
    	       curr.next=curr.prev;
    	       curr.prev=temp;
    	       curr=temp;
    	    }
    	    
    	    //these two changes, when I made later the code worked. This was because I had changed a next and hence it
    	    //was flying over b and running on null thus leading to npe.
    	    b.prev=a.prev; 
    	    a.next=b.next;
    	    
    	    //last two changes.
    	    b.next=bbn;
    	    a.prev=aan;
    	    
    	    return 0; //indicates completion.
     }
     
     public void showRev()
     {
 Node curr=tail;
    	 
    	 while(curr!=null)  //very silly mistake I had included head instead of curr.
    	 {
    		 System.out.print(curr.x+" ");
    		 curr=curr.prev;
    	 }
    	 System.out.println();
     }
     
     public void reverse(int[] indices,Node head,Node tail)
     {
    	 //handle errors later
    	  
    	 //these represent the indices. thet are zero indexed.
    	 
    	  int left,right,n,countl=0,countr=0;
    	  Node a=head,b=head,currl,currr,nba,nab,imen=null,imep=null,temp1,temp2;
    	  
    	  n=indices.length;
    	  
    	  ///initial position.
    	  left=indices[0]; 
    	  right=indices[n-1];
    	  
    	  while(countl!=left)
    	       	{a=a.next;
    	       	 countl++;
    	       	}
    	  
    	  while(countr!=right)
	       	{b=b.next;
	       	 countr++;
	       	}
        
    	   currl=a;
    	   currr=b;
    	  // a and b are at the right place.
    	  
    	 //assuming inside. get pointers to loc before a and b because two pointers need to be changed there.
    	   //have changed the outside pointers.
    //	  nba=a.prev;
    //	  nab=b.next;
    	  
    	  //the two changes required.
    //	  nba.next=b;
    //	  nab.prev=a;
    	  
    	  
    	  for(int i=0;i<(n/2);i++)
    	  {
    		 left=indices[i];
    		 right=indices[n-i-1];
    		 
    		 //move currl to proper position
    		 while(countl!=left)
    		 {
    			// System.out.println("stuck in left loop");
    			 currl=currl.next;
    			 countl++;
    		 }
    		 
    		//move currr to proper position
    		 while(countr!=right)
    		 {
    			 //System.out.println("stuck in right loop");
    			 currr=currr.prev;
    			 countr--;
    		 }
    		 
    		 
    		 //now make changes in the pointers.
    		 
    		 //save the path ahead, as this is where we are making mods.
    		 
    		 imen=currl.next;
    		 imep=currr.prev;
    		 
    		 //check if conse or not.
    		 
    		 if (indices[n-i-1]-indices[i]!=1) // not consecutive,what if I remove this if?
    		 {
    			 //save currl's info.
    			 temp1=currl.next;
    			 temp2=currl.prev;
    			 
    			 //deals with the inside cases.
    			 if (currl.prev!=null && currr.next!=null) 
    			 {currl.prev.next=currr;
    			 currr.next.prev=currl; // change made. this is worsening things.
    			 currr.prev.next=currl;
    			 currl.next.prev=currr;
    			 
    			 //left side changed.
    			 currl.next=currr.next;
    			 currl.prev=currr.prev;
    			 currr.next=temp1;
    			 currr.prev=temp2;
    			 }
    			 
    			 else
    			 {
    				 if (currl.prev==null && currr.next==null)
    				 {
    					 head=currr;
    					 tail=currl;
    					 
    					 currl.next=currr;
    					 currr.prev=currl;
    					 currl.prev=currr.prev;
    					 currr.next=currl.next;
    					 head=currr;
    					 tail=currl;
    					 
    				 }
    			 }
    			 countl++;
    			 countr--; //check if we decrease this.
    			 currl=imen;
    			 currr=imep;
    		 }
    		 
    		 //do this if consecutive
    		 else
    		 {
    			 //save currl's info.
    			 temp1=currl.next;
    			 temp2=currl.prev;
    			 
    			 currl.prev.next=currr;
    			 currr.next.prev=currl; // change made. 
    			 
    			// currr.prev.next=currl;
    			// currl.next.prev=currr;
    			 
    			 //left side changed.
    			 currl.next=currr.next;
    			 currl.prev=currr;
    			 currr.next=currl;
    			 currr.prev=temp2;
    			 
    			 countl++;
    			 countr--; //check if we decrease this.
    			 currl=imen;
    			 currr=imep;
    			 
    		 }
    	  }
    	  //at the end of this loop the result should be obtained.
     }
}

