
import java.util.Scanner;

public class Tester 
{

	public static void main(String[] args) 
	{
		
         Scanner sc=new Scanner(System.in);
         
         Queue q=new Queue();
         
         //insert into queue
         for(int i=0;i<5;i++)
         {
        	 //to handle error we need to ensure user nows what string to input.
        	q.insert(Integer.parseInt(sc.nextLine())); 
         }
         
         q.show(); //display.
         
         String permu=sc.nextLine();
        
         if (permu.length()!=q.size)
        	 System.out.println("YOur permu is not valid");
         else
         { 
        	 int temp,i=1;
 		Queue q1=new Queue();
 		
 		//used in looping
 		int slength=permu.length();
 		
 		//till first element is not remaining.
 		
 		int tempsize=q.size,wss=0;
 		
 		
 		while(tempsize>1)
 		{   
 		 
 			
 			//System.out.println("I am here");
 			temp=q.delete();
 			
 			if ((temp+48)!=permu.charAt(0))
 				{
 				 
 				 q1.insert(temp);
 				 tempsize--;
 				}
 			else
 				q.insert(temp); //if first element.
 		}
 		
 		//check if the lone element remaining indeed is the first char or not, if not input is wrong.
 		   temp=q.delete();
 		    if ((temp+48)!=permu.charAt(0))
 		    	System.out.println("Input string not valid");
 		
 		    else
 		{
 		//at the end of this the first ele should be at the beginnig.
 		   q.insert(temp); //put it back if no problem found.
 		
 		//till then permu
 		int notvalid=0;   
 		for(i=1;i<slength;i++)
		{
		  int	notfound=0;
		  notvalid=0;
			while(true)
			{
		     if (notfound>permu.length()-i)
		     {
		    	 //it implies that the input is wrong.
		    	 System.out.println("Input is not valid");
		    	 notvalid=1;
		    	 break;
		     }
				 
				temp=q1.delete();
				if ((temp+48)!=permu.charAt(i))
					{q1.insert(temp);
				     notfound++;
					}
				else
				{
					q.insert(temp);
				//	wcc=0; //change
					break;
				}
			}
			
			if (notvalid==1)
				break;
		}
 		//at the end of this we should have our required permu.
 		if (notvalid!=1)
 		q.show();
	   }
	}
       sc.close();
	}
  
	 
	/*public static void permute(Queue q,String permu)
	{
		  //we need to change q as the permu.
		int temp,i=1;
		Queue q1=new Queue();
		
		//used in looping
		int slength=permu.length();
		
		//till first element is not remaining.
		while(q.size>1)
		{
			temp=q.delete();
			
			if (temp!=permu.charAt(0))
				q1.insert(temp);
			else
				q.insert(temp); //if first element.
		}
		
		//at the end of this the first ele should be at the beginnig.
		
		
		//till then permu
		for(i=2;i<slength;i++)
		{
			int wcc=0;
			
			while(true)
			{
				if (wcc>100)
				{
					System.out.println("Your permutation is not valid");
					break;
				}
				temp=q1.delete();
				if (temp!=permu.charAt(i))
					{q1.insert(temp);
					 wcc++;
					}
				else
				{
					q.insert(temp);
					wcc=0; //change
					break;
				}
			}
		}
		//at the end of this we should have our required permu.
		q.show();
	}*/
}
