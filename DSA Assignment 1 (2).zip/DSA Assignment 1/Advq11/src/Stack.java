
//basic stack to be implemented using linklists.

public class Stack 
{
	//stack attributes.
	private Node head=null;
    private Node tail=null;
    //private Node tailprev=null;
    int size=0;
    
    //methods.
    
   //completed with size memory
    public void push(int x)
    {
        //if stack is empty, fill in.
    	if (x!=-5)
    {	if (head==null)
    	{
    		head=new Node();
    		head.setData(x);
    		head.setNext(null);
    		tail=head;
    		size++;
    	}
    	
    	else
    	{
    		//remem size.
    	//	tailprev=tail;  //remember previous loc of tail.
    		tail.setNext(new Node());
    	
    		//tail moved ahead.
    		tail=tail.getNext();
    		tail.setData(x);
    		tail.setNext(null);
    		size++;
    	}
    }
    }
    
    public int pop()
    {
    	int element;
    	Node temp=head;
    	if (head==null)
    		return -5; //represents error. 
    	
    	if (head==tail)
    	{
    		element=head.getData();
    		head=null;
    		tail=null;
    		size=0;
    		return element;
    	}
    	
    	//otherwise
    	element=tail.getData();
    	//tailprev.setNext(null);
    	//tail=tailprev;
    	
    	while(temp.getNext()!=tail)
    		temp=temp.getNext();
    	
    	tail=temp;
    	tail.setNext(null);
    	size--;
    	return element;
    }
    
    public void show()
    {
       Node temp=head;
       if (head!=null)
       {while(temp!=tail.getNext())
       {
    	   System.out.print(temp.getData()+" ");
    	   
    	   //I had forgotten this. silly mistake.
    	   temp=temp.getNext();
    			   
       }
       }
       System.out.println();
    }
    
}
