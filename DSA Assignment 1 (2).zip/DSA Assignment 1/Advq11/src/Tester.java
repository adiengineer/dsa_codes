import java.util.Scanner;
public class Tester 
{

	public static void main(String[] args) 
	{
	Scanner sc=new Scanner(System.in);
        
	    int n=Integer.parseInt(sc.nextLine());
	    
	     Stack ori=new Stack();
	     Stack targ=new Stack();
	     Stack aux=new Stack();
	     
	     for(int i=0;i<n;i++)
	    	 ori.push(Integer.parseInt(sc.nextLine())); // fill with n elements.
	     
	     int size=n;
	     
	     trans(size,ori,targ,aux);
	     
	     targ.show();
	     
	     sc.close();
	}

	
	public static void trans(int size,Stack ori,Stack targ,Stack aux)
	{   
		
	
		if (size<=0)
			{
			    
			targ.push(ori.pop());
			
			   return ; //base case
			}
		
		 trans(size-1,ori,aux,targ);
	
		  targ.push(ori.pop());
		  
		  trans(size-1,aux,targ,ori);
		  return;
	}
}
