
//this is running correctly. 
public class StackUsingCircQueues 
{
   //use two queues.
	//attributes of the stack.
	
	//made two queues.
	CircArrayQueue q1=new CircArrayQueue();
	
	
	CircArrayQueue q2=new CircArrayQueue();
     

	int size=0;  //elements present in it.
	
	public void setsize()   //of stack by setting size of queues.
	{
		q1.setSize(5);
		q1.makeQue();
		q2.setSize(5);
		q2.makeQue();
	}
	
	public void push(int x)
	{
		//just insert into the queue.
	  q1.enqueue(x);
	  size++;
	}
	
	public int pop()
	{
		int waste; 
		
		if (q1.currsize<=1 )
			 {System.out.println("Stack is empty");
			   q1.front=0;
			   q1.back=0;
			  return -5;
			 }
		 
		 
			 //in the end decrement size.
			 
			 //while q1 is not empty or till all elements are removed.
			 while(q1.currsize>0)
			q2.enqueue(q1.dequeue());
			 
			 //till unwanted element only remains in q2
			 while(q2.currsize>1)
			 q1.enqueue(q2.dequeue());
			 
			 //pop has been completed.Now get rid of unwanted element.
			 
			waste=q2.dequeue();
			 size--;
		 return 0;
	}
	
	public void show()
	{
		    q1.show(); //as q2 is just for implementing the pop operation.The stack actually exists in q1.
	}
}
