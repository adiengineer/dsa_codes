
//this is running correctly. 
public class StackUsingQueues 
{
   //use two queues.
	//attributes of the stack.
	
	//made two queues.
	Queue q1=new Queue();
	Queue q2=new Queue();
	int size=0;  //elements present in it.
	
	public void push(int x)
	{
		//just insert into the queue.
	  q1.insert(x);
	  size++;
	}
	
	public void pop()
	{
		int waste; 
		
		if (size<=0)
			 System.out.println("Stack is empty");
		 else
		 {
			 //in the end decrement size.
			 
			 //while q1 is not empty or till all elements are removed.
			 while(q1.size>0)
			q2.insert(q1.delete());
			 
			 //till unwanted element only remains in q2
			 while(q2.size>1)
			 q1.insert(q2.delete());
			 
			 //pop has been completed.Now get rid of unwanted element.
			 
			waste=q2.delete();
			 size--;
		 }
	}
	
	public void show()
	{
		    q1.show(); //as q2 is just for implementing the pop operation.The stack actually exists in q1.
	}
}
