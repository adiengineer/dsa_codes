import java.util.Scanner;
public class Main 
{
    // we have implemented a queue completely using link list implementation which regognized size and handles errors.
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
       		//check if queue is working properly.
       
		//code for testing out the basic queue.
		/*
		Queue q=new Queue();
        
        for(int i=0;i<5;i++)
        {
        	q.insert(Integer.parseInt(sc.nextLine()));
        	q.show();
        }
        
        for(int i=0;i<6;i++)
        {int check;
        
        	check=q.delete();
        	if (check==-5)
        		System.out.println("Queue is empty");
        	else
        	q.show();
        }
        
        */
		
		//Code for testing stack implemented using two queues.
		/*
		StackUsingQueues qstack =new StackUsingQueues();
		
		 for(int i=0;i<5;i++)
	        {
	        	qstack.push(Integer.parseInt(sc.nextLine()));
	        	qstack.show();
	        }
		
		 for(int i=0;i<7;i++)
	        {
	        	qstack.pop();
	        	qstack.show();
	        }
		 */
		
		//code for testing basic stack using ll.
		/*
		Stack s =new Stack();
		for(int i=0;i<7;i++)
        {
        	s.push(Integer.parseInt(sc.nextLine()));
        	s.show();
        }
		
		for(int i=0;i<9;i++)
        {
        	int check=s.pop();
        	
        	if (check<0)
        		System.out.println("Stack is empty");
        	
        	s.show();
        }*/
		
		//code for implementing QueueUsingStack
		/*QueueUsingStack squeue=new QueueUsingStack();
		
		 for(int i=0;i<8;i++)
	        {
	        	squeue.enqueue(Integer.parseInt(sc.nextLine()));
	        	squeue.show();
	        }
		
		 for(int i=0;i<10;i++)
	        {
	        	squeue.dequeue();
	        	squeue.show();
	        }
	        
	  
	     *     
		 */
		
		  //code for testing basic stack using arrays.
		
	/*	ArrayStack s=new ArrayStack();
		s.setSize(10);
		s.makestk();
		
		 int size=s.size;
		 
		//fill in array 
		for(int i=0;i<size+4;i++)
		 {
			 s.push(Integer.parseInt(sc.nextLine()));
		 }
		s.show();
		
		for(int i=0;i<size+5;i++)
		 {
			 s.pop();
				 
			 s.show();
				 
		 }
		
		
        sc.close(); */
		
		//code for testing cir queue.
        
		/*CircArrayQueue q=new CircArrayQueue();
		q.setSize(5);
		q.makeQue();
		
		for(int i=0;i<7;i++)
		 {
			 q.enqueue(Integer.parseInt(sc.nextLine()));
			 q.show();
		 }  
		
		for(int i=0;i<7;i++)
		 {
			 q.dequeue();
			 q.show();
		 }  */
		
		//code for checking stack using two circular queues.
		
		StackUsingCircQueues sq=new StackUsingCircQueues();
		sq.setsize();
		
		 for(int i=0;i<5;i++)
	        {
	        	sq.push(Integer.parseInt(sc.nextLine()));
	        	sq.show();
	        }
		
		 for(int i=0;i<7;i++)
	        {
	        	int popresult=sq.pop();
	        	
	        	if (popresult!=5)
	        	sq.show();
	        }
		 
		sc.close();
	}

}
