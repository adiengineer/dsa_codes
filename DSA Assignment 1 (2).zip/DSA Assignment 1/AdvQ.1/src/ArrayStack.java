
public class ArrayStack 
{



   //stack using an array
	//predeterminded size.
	
	
	int size;
	int[] stk;
	
	//setter
	
	public void setSize(int size) 
	{
		this.size = size;
	}
	
	public void makestk()
	{
	stk=new int[size];	
	}
	
	int top=-1;
	

	public void push(int x)
	{
		if (top==(size-1))
		{
			System.out.println("Stack is full");
			
		}
		else
			{top++;
			 stk[top]=x;
			}
	}
	
	public int pop()
	{ 
		 int element;
	 	if (top<0)
	 		{  System.out.println("Stack is empty");
	 		  return -100; //indicates that error exists.
	 		}
	 	else
	 	{
	 		element=stk[top];
	 		top--;
	 		return element;
	 	}
	}
	
	
	
	public void show()
	{
		if (top>=0)
		{for(int i=0;i<=top;i++)
			System.out.print(stk[i]+" ");
		System.out.println();
		}
	}

}
