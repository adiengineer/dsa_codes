
public class QueueUsingStack 
{
	Stack s1=new Stack();
	Stack s2=new Stack();
	int size=0;  //elements present in it.
	
	public void enqueue(int x)
	{
		//just insert into the queue.
	  s1.push(x);
	  size++;
	}
	
	public void dequeue()
	{
		int waste; 
		
		if (size<=0)
			 System.out.println("Queue is empty");
		 else
		 {
			 //in the end decrement size.
			 
			 //while q1 is not empty or till all elements are removed.
			 while(s1.size>0)
			s2.push(s1.pop());
			 
			 //till unwanted element only remains in q2
			 waste=s2.pop();
			 while(s2.size>0)
			 s1.push(s2.pop());
			 
			 //dequeue has been completed.Now get rid of unwanted element.
			 
			
			 size--;
		 }
	}
	
	public void show()
	{
		    s1.show(); //as q2 is just for implementing the pop operation.The stack actually exists in q1.
	}
}
