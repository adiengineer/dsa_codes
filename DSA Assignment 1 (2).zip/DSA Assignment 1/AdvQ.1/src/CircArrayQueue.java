
public class CircArrayQueue 
{
	int size;
	int currsize=0; //use this.
	int[] arr;
	int front,back;
	//setter
	
	//always reset to front back equal to zero.
	public void setSize(int size) 
	{
		this.size = size+1;
		front=0;
		back=0;
	}
	
	public void makeQue()
	{
	arr=new int[size+1];   // I don't use the first position of the array. So to hold 5 I need array of 6.	
	} 
	 // basic attributes of the queue and its size settigns.
	 // for first addition I need a special condition to handle.
	
	//now enqueue
	
	public void enqueue(int x)
	{
		int insertat=back;
	       insertat++;
	       
	       if (insertat>size-1)
	    	   insertat=insertat%size;
	       
	       if (insertat!=front)
	       {
	    	   arr[insertat]=x;
	    	   back=insertat;
	    	   currsize++;
	       }
	       
	       else
	       {
	    	   System.out.println("Queue is full");
	       }
	}
	
	public int dequeue()
	{   int element=arr[front];
		int temp=front;
		
		temp++;
		
		if (front==0 && back==0)
			{System.out.println("Queue is empty");
			 return -5;
			}
		
	//	if (temp>size-1)
		// temp=temp%size;
		 
		 //then queue is empty.
		 if (temp>back &&(front==back))
		 {
			 //then I dont want any element so reset to initial state.
			 element=arr[front];
			 front=0;
			 back=0;
			 currsize=0;
			 return element;
		 }
		 
		 if (front==0)
		 {
			 element=arr[temp];
			 temp++;
			 front=temp;
			 currsize--;
			 return element;
		 }
		 if (temp>size-1)
			 temp=temp%size;
		 
		// if (!(temp>back &&(front==back)))
			  element=arr[front];
			 front=temp;
			 currsize--;
			
			 
		 return element;
	}
	
	public void show()
	{
		int temp;
		if (this.currsize==1 && front==0 &&back==0) //changed from front==0 and back==0.
			System.out.println();
		
		else
		{
			
			
			if (front==0)
			temp=front+1;
			else
				temp=front;
			
			while(temp!=back)
			{
				System.out.print(arr[temp]);
				
				temp++;
				
				if (temp>size-1)
					temp=temp%size;
			}
			System.out.print(arr[back]);
			System.out.println();
		}
	}
}
