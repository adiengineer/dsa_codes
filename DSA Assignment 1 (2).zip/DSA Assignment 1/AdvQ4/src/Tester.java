
public class Tester 
{

	public static void main(String[] args) 
	{
		ArbTree at=new ArbTree();
        
		  at.insert("",1);
		  at.insert("0",2);
		  at.insert("1",3);
		  at.insert("2",4);
		  at.insert("00",5);
		  at.insert("10",6);
		  at.insert("11",7);
		  at.insert("12",8);
		  at.insert("20",9);
		  at.insert("21",10);
		  at.insert("210",11);
		  
		  at.printlevel();
		  
		  at.convert(at.root,at.binTree.root);
		  System.out.println();
		  System.out.println("The binary tree is:");
		  at.binTree.printlevel();
	}

}
