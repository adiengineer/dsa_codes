
public class BinQueueNode
{  
	 BinNode data=null;
	 BinQueueNode next=null;
    
	public BinNode getData() {
		return data;
	}
	public void setData(BinNode data) {
		this.data = data;
	}
	public BinQueueNode getNext() {
		return next;
	}
	public void setNext(BinQueueNode next) {
		this.next = next;
	}

     
     
}