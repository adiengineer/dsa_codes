
public class Node 
{
   int key;
   
   Node parent; //reference to the parent.
   Node[] children=new Node[5]; // array of references to the childeren,some fixed value.
   
             Node(int key,Node parent)
             {
            	 this.key=key;
            	 this.parent=parent;
             }
  
}
