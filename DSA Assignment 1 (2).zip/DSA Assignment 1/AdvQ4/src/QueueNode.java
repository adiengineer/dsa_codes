




public class QueueNode
{  
	 Node data=null;
      QueueNode next=null;
    
	public Node getData() {
		return data;
	}
	public void setData(Node data) {
		this.data = data;
	}
	public QueueNode getNext() {
		return next;
	}
	public void setNext(QueueNode next) {
		this.next = next;
	}

     
     
}

