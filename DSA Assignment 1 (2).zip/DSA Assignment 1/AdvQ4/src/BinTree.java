
public class BinTree 
{
   BinNode root=null;
   
   public void insert(BinNode loc,int x)
   {
  	 //Node curr=root; // this is our temperory node.
  	 //int i;
  	 
  	 //if root is null 
  	   if (loc==root)
  		   {
  		      if(root.left==null)
  		    	  root.left=new BinNode(x,null); //root cant have a parent.
  		      else
  		    	  root.right=new  BinNode(x,null);
  		      
  		      return;
  		   }
  	   
  	   //insert at loc which in our code will be node where last insertion takes place. 
  	   if (loc.left==null)
  	    {
  		  loc.left=new BinNode(x,loc);
  	    }
  	    else if (loc.right==null)
  	    	loc.right=new BinNode(x,loc);
  	    else
  	    	{System.out.println("Wrong loc");
  	    	 return;
  	    	}
   }
   
   public void printlevel()
   {
  	 int newlinecount=0;
  	 BinQueue q =new BinQueue();
  	 
  	 BinNode curr=root;
  	  
  	  if (curr==null)
  	  {
  		  System.out.println("Nothing to print");
  		  return;
  	  }
  	  
  	System.out.println(curr.x);
  	
  	    //assume 5.
  	//now enqueue all children.
  
  	
  		if (curr.left!=null)
  		q.insert(curr.left);
  	    if (curr.right!=null)
  	    	q.insert(curr.right);	
  	
  	newlinecount=q.size;
  	
  	while(q.size!=0)
  	{
  	    curr=q.delete();
  		
  	  if (curr.left!=null)
    		q.insert(curr.left);
    	    if (curr.right!=null)
    	    	q.insert(curr.right);
  		
  		
  		System.out.print(curr.x+"p"+curr.parent.x+" ");
  		newlinecount--;
  		
  		if (newlinecount==0)
  			{System.out.println();
  		newlinecount=q.size;    		
  			}
  	}
   }
}
