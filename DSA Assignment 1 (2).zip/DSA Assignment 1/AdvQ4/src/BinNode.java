
public class BinNode 
{
    int x;
    BinNode left;
    BinNode right;
    BinNode parent;
    
    BinNode(int x, BinNode parent)
    {
       this.x=x;
       this.parent=parent;
    }
}
