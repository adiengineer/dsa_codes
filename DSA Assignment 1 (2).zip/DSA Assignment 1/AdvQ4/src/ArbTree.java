
public class ArbTree 
{
     Node root=null;
     
     public void insert(String path,int key)
     {
    	 Node curr=root; // this is our temperory node.
    	 int i;
    	 
    	 //if root is null 
    	 if (path.length()==0)
    		 {root=new Node(key,root); //element inserted.
    	     return;
    		 }
    	 
    	 
    		   for(i=0;i<=path.length()-2;i++)
    		   {
    			   curr=curr.children[path.charAt(i)-48];
    			   
    			   //path is wrong.
    			   if (curr==null)
    				   {System.out.println("Path is wrong");
    				    return;
    				   }
    		   }
    		   
    		   //inserted at the correct place and parents remembered.
    		   curr.children[path.charAt(i)-48]=new Node(key,curr);
    	        
    	     
     }
     
     public void printlevel()
     {
    	 int newlinecount=0;
    	 Queue q =new Queue();
    	 
    	 Node curr=root;
    	  
    	  if (curr==null)
    	  {
    		  System.out.println("Nothing to print");
    		  return;
    	  }
    	  
    	System.out.println(curr.key);
    	
    	    //assume 5.
    	//now enqueue all children.
    	for(int i=0;i<5;i++)
    	{
    		if (curr.children[i]!=null)
    		q.insert(curr.children[i]);
    	}
    	
    	newlinecount=q.size;
    	
    	while(q.size!=0)
    	{
    	    curr=q.delete();
    		
    		for(int i=0;i<5;i++)
        	{
        		if (curr.children[i]!=null)
        		q.insert(curr.children[i]);
        	}
    		
    		
    		System.out.print(curr.key+"p"+curr.parent.key+" ");
    		newlinecount--;
    		
    		if (newlinecount==0)
    			{System.out.println();
    		newlinecount=q.size;    		
    			}
    	}
     }
     
     BinTree binTree= new BinTree();
          
     
    
     
     
     
     
     public void convert(Node curr, BinNode placeOfLastInsert)
     {
    	 int childplace=0;
    	 
    	 //keep the binary tree ready.
    	 if (curr==root)
    	   {
    		  binTree.root=new BinNode(curr.key,null);
    		  placeOfLastInsert=binTree.root;
    	   }
    	 
    	 if (curr==null)
    		  return;
    	 
    	 //if all children visited.
    	
    	while (true) 
    	 {   if (childplace>=curr.children.length)
    		 return;
    	 
    	 //then we are at first child. Then insert at placeofLastinsert left.
    	     if (childplace==0 && curr.children[0]!=null)
    	     {
    		 placeOfLastInsert.left=new BinNode(curr.children[0].key,placeOfLastInsert);
    		 
    		 placeOfLastInsert=placeOfLastInsert.left;
    		 
    		  //make the recursive call
    		     convert(curr.children[0],placeOfLastInsert);
    	     }
    	     
    	     else
    	     {
    	    	 if (curr.children[childplace]!=null)
    	    	 {
    	    		 //we need to insert it at its sibling.
    	    		 binTree.insert(placeOfLastInsert, curr.children[childplace].key);
    	    		 
    	    		 if (placeOfLastInsert.right==null)
    	    			 placeOfLastInsert=placeOfLastInsert.left;
    	    		 else
    	    			 placeOfLastInsert=placeOfLastInsert.right;
    	    		 
    	    		 convert(curr.children[childplace],placeOfLastInsert);
    	    	 }
    	     }
    	     
    	     childplace++; //increment at evert iteration of the loop.
    	 }
     }
}
